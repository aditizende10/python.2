import numpy as np
arr1 = np.array([1, 2, 3])
arr2 = np.array([4, 5, 6])
addition = arr1 + arr2
print(addition)
subtraction=arr1 - arr2
print(subtraction)
multiplication= arr1 * arr2
print(multiplication)
division=arr1 / arr2 
print(division) 
