import pandas as pd
data = {
    'Name': ['Aniket', 'Karan', 'Kunal'],
    'Age': [25, 30, 35]
}
df = pd.DataFrame(data)
print(df)
