# Emp={"Name":"AV",
#      "Age":20,
#      "City":"Kolhapur",
#      "Position":"Developer",
#      "Salary":50000,
#      "Company":"BlackRock"}

Emp=dict({"Name":"Aniket",
     "Age":20,
     "City":"Kolhapur",
     "Position":"Developer",
     "Salary":50000,
     "Company":"BlackRock"},)
# print(Emp)
# print(type(Emp))

# print(Emp["Name"])
# for i in Emp:
#     print(i)
    
# for i in Emp.keys():
#     print(i)
    
# for i in Emp.values():
#     print(i)

