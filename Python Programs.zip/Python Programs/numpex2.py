import numpy as np
A = np.array([[1, 2], [3, 4]])  
B = np.array([[5, 6], [7, 8]])   
result = np.dot(A, B)
print("Dot Product:")
print(result)
print("Array A:",A)
print("Number:",)
print(7)

