cars=["BMW","Volvo","Mercedes","Porsche","Aston Martin"]
print(cars)
cars.pop(1)
cars.append("Bently")
for i in cars:
    print(i)
    
import nump as np
arr= np.array([1,2,3,4,5,6,7,8,9,10],ndmin=2)
print(arr)
print(arr.ndim)