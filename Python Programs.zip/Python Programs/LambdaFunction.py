add=lambda num: num+10
print(add(9))

square=lambda n:n * n
print(square(8))