print("Number:")
n = int(input())

for i in range(n):
    print("*")
    for j in range(n-1):
        print("\n")