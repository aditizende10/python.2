print("Enter the number")
n = int(input())
if(n==0):
    print("Number is zero")
else:
    print("Number is non zero")