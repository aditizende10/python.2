print("Enter First Number: ")
a = int(input())
print("Enter Second Number: ")
b = int(input())
print("Addition: ",a+b)
print("Substration is: ",a-b)
print("Multiplication is: ",a*b)
print("Division is: ",a/b)

