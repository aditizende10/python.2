# str = "Shailesh Sawant"
print("Enter the String")
str = str(input())
for i in str:
    print(i)

print(str[0:8])
for i in range(0,9):
    print(i)

