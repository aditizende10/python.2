#first program in python language
str = "Hello world"
print(str)

list = [1,2,3,4,5,6,7]
print(list)
print(type(list))

tuple = ("DYP","CET","Kolhapur")
print(tuple)
print(type(tuple))

set = {"Eleven","Lucas","Max","Max"}
print(set)
print(type(set))

dict = {"car":"Ford", 
        "Model":"Mustang",
        "year":1969}
print(dict)
print(type(dict))

complex = 54+1j
print(complex)
print(type(complex))

n = int(input())
for i in range(1,11):
    print("",n," * ",i,"=",n*i)
    
