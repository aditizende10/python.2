print("Enter the number")
n = int(input())


    